<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <meta name="googlebot" content="noindex" />
    <meta name="description" content="">
    <meta name="author" content="yeXDev">
    <title>VezzyGame | Giriş Yap</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
    <link href="https://www.vezzygame.com/admin/extends/dist/css/style.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://www.vezzygame.com/admin/extends/dist/css/custom.css">
    <link rel="stylesheet" href="https://www.vezzygame.com/admin/extends/assets/libs/notify.css">
    <script type="text/javascript">
      var URL = "https://www.vezzygame.com";
      var ADMIN_URL = "https://www.vezzygame.com/admin";
    </script>
    <script src="https://www.vezzygame.com/admin/extends/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="https://www.vezzygame.com/admin/extends/assets/libs/notify.js" charset="utf-8"></script>
    <script src="https://www.vezzygame.com/admin/extends/assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="https://www.vezzygame.com/admin/extends/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style media="screen">
    body {
      background: #ecf0f1;
    }
    .card {
      box-shadow: 0px 2px 9px rgb(232, 225, 225);
    }
  </style>
</head>
<body>
  <div class="row d-flex justify-content-center align-items-center" style="width: 100%;">
    <div class="col-lg-4 d-flex justify-content-center"  style="margin-top: 100px;">
      <div class="card rounded" style="width: 100%;">
        <div class="card-body">
          <div class="text-center">
            <h2 class="font-weight-bold">Giriş Yap</h2>
          </div>
          <form class="requestForm" action="/app/controller/user.controller.php" data-reload-page="/index.php?view=dashboard" autocomplete="off" method="post" onsubmit="return false;">
            <div class="form-group">
              <label for="">Kullanıcı Adı</label>
              <input type="text" name="user_name" value="" class="form-control">
            </div>
            <div class="form-group">
              <label for="">Parola</label>
              <input type="password" name="user_password" value="" class="form-control">
            </div>
            <div class="float-left">
              <div class="custom-control custom-checkbox d-flex justify-content-center align-items-center">
                <input type="checkbox" class="custom-control-input" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Beni hatırla</label>
              </div>
            </div>
            <input type="text" name="login" hidden value="login">
            <div class="float-right">
              <button type="submit" class="btn btn-secondary">Giriş Yap</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="https://www.vezzygame.com/admin/extends/assets/libs/main.js?x=57"></script>
</body>
</html>
